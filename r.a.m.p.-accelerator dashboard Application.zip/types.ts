export interface Shift {
  id: number;
  name: string;
  description: string;
  plannedStart: string; // YYYY-MM-DD
  plannedEnd: string;
  plannedBudget: number;
  actualStart: string;
  actualEnd: string;
  actualBudget: number;
}

export interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  wage: number;
  cohortId: string;
  billableHours: number;
  actualHours: number;
}

export interface Cohort {
  id: string;
  name: string;
}

export interface TravelRequest {
  id: string;
  employeeId: string;
  lodgingCost: number;
  distanceMiles: number;
  totalReimbursement: number;
  status: 'Pending' | 'Approved';
}

export interface ExternalRep {
  id: string;
  name: string;
  company: string;
}

export interface TooltipConfig {
  [key: string]: string;
}

export interface AppState {
  shifts: Shift[];
  employees: Employee[];
  travelRequests: TravelRequest[];
  externalReps: ExternalRep[];
  tooltips: TooltipConfig;
  cohorts: Cohort[];
}
