import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { Forms } from './components/Forms';
import { Admin } from './components/Admin';
import { INITIAL_SHIFTS, INITIAL_EMPLOYEES, INITIAL_TOOLTIPS, INITIAL_COHORTS, INITIAL_EXTERNAL_REPS } from './constants';
import { AppState, Shift, TravelRequest, ExternalRep } from './types';

const App: React.FC = () => {
  const [isDark, setIsDark] = useState(true);
  const [activeView, setActiveView] = useState('dashboard');
  
  // Centralized State
  const [state, setState] = useState<AppState>({
    shifts: INITIAL_SHIFTS,
    employees: INITIAL_EMPLOYEES,
    tooltips: INITIAL_TOOLTIPS,
    cohorts: INITIAL_COHORTS,
    externalReps: INITIAL_EXTERNAL_REPS,
    travelRequests: []
  });

  // Apply Theme Class
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  // --- Actions ---

  const updateShift = (updatedShift: Shift) => {
    setState(prev => ({
      ...prev,
      shifts: prev.shifts.map(s => s.id === updatedShift.id ? updatedShift : s)
    }));
  };

  const updateTooltip = (key: string, val: string) => {
    setState(prev => ({
      ...prev,
      tooltips: {
        ...prev.tooltips,
        [key]: val
      }
    }));
  };

  const addExternalRep = (rep: ExternalRep) => {
    setState(prev => ({
      ...prev,
      externalReps: [...prev.externalReps, rep]
    }));
  };

  const addHours = (empId: string, billable: number, actual: number) => {
    setState(prev => ({
      ...prev,
      employees: prev.employees.map(e => {
        if (e.id === empId) {
          return {
            ...e,
            billableHours: e.billableHours + billable,
            actualHours: e.actualHours + actual
          };
        }
        return e;
      })
    }));
  };

  const submitTravel = (req: TravelRequest) => {
    setState(prev => ({
      ...prev,
      travelRequests: [...prev.travelRequests, req]
    }));
  };

  return (
    <Layout 
      activeView={activeView} 
      setView={setActiveView}
      isDark={isDark}
      toggleTheme={() => setIsDark(!isDark)}
    >
      {activeView === 'dashboard' && (
        <Dashboard 
          shifts={state.shifts} 
          employees={state.employees} 
          tooltips={state.tooltips} 
        />
      )}
      
      {activeView === 'forms' && (
        <Forms 
          state={state} 
          addHours={addHours}
          submitTravel={submitTravel}
        />
      )}

      {activeView === 'admin' && (
        <Admin 
          state={state} 
          updateShift={updateShift}
          updateTooltip={updateTooltip}
          addExternalRep={addExternalRep}
        />
      )}
    </Layout>
  );
};

export default App;
