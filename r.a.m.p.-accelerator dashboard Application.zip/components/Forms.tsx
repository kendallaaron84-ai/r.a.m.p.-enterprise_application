import React, { useState } from 'react';
import { AppState, TravelRequest, Employee } from '../types';
import { Send, MapPin, Calculator, AlertCircle } from 'lucide-react';

interface FormsProps {
  state: AppState;
  addHours: (empId: string, billable: number, actual: number) => void;
  submitTravel: (req: TravelRequest) => void;
}

export const Forms: React.FC<FormsProps> = ({ state, addHours, submitTravel }) => {
  const [activeTab, setActiveTab] = useState<'hours' | 'travel'>('hours');

  // Hours Form State
  const [selectedEmp, setSelectedEmp] = useState('');
  const [billable, setBillable] = useState('');
  const [actual, setActual] = useState('');
  const [hoursError, setHoursError] = useState('');
  const [hoursSuccess, setHoursSuccess] = useState('');

  // Travel Form State
  const [travelEmp, setTravelEmp] = useState('');
  const [lodging, setLodging] = useState('');
  const [miles, setMiles] = useState('');
  const [travelSuccess, setTravelSuccess] = useState('');

  const handleHoursSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setHoursError('');
    setHoursSuccess('');

    const b = parseFloat(billable);
    const a = parseFloat(actual);

    if (b > a) {
      setHoursError('Validation Error: Billable Hours cannot exceed Actual Hours worked.');
      return;
    }

    if (!selectedEmp) {
      setHoursError('Please select an employee.');
      return;
    }

    addHours(selectedEmp, b, a);
    setHoursSuccess('Hours logged successfully.');
    setBillable('');
    setActual('');
  };

  const handleTravelSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTravelSuccess('');

    if (!travelEmp) return;

    const m = parseFloat(miles) || 0;
    const l = parseFloat(lodging) || 0;
    // Auto-calculate reimbursement: Miles * 0.67
    const reimbursement = (m * 0.67) + l;

    const newReq: TravelRequest = {
      id: Date.now().toString(),
      employeeId: travelEmp,
      lodgingCost: l,
      distanceMiles: m,
      totalReimbursement: reimbursement,
      status: 'Pending'
    };

    submitTravel(newReq);
    setTravelSuccess(`Request submitted. Estimated Reimbursement: $${reimbursement.toFixed(2)}`);
    setLodging('');
    setMiles('');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
      <div className="flex space-x-4 border-b border-gray-200 dark:border-gray-700 pb-1">
        <button
          onClick={() => setActiveTab('hours')}
          className={`pb-3 px-4 text-sm font-medium transition-colors ${
            activeTab === 'hours' 
            ? 'border-b-2 border-ramp-gold text-ramp-gold' 
            : 'text-gray-500 hover:text-gray-700 dark:text-gray-400'
          }`}
        >
          Employee Hours
        </button>
        <button
          onClick={() => setActiveTab('travel')}
          className={`pb-3 px-4 text-sm font-medium transition-colors ${
            activeTab === 'travel' 
            ? 'border-b-2 border-ramp-gold text-ramp-gold' 
            : 'text-gray-500 hover:text-gray-700 dark:text-gray-400'
          }`}
        >
          Travel Request
        </button>
      </div>

      {activeTab === 'hours' && (
        <div className="bg-white dark:bg-ramp-surface p-8 rounded-lg shadow-lg border border-gray-100 dark:border-gray-700">
          <h3 className="text-xl font-bold mb-6 text-gray-900 dark:text-ramp-text">Log Billable Hours</h3>
          <form onSubmit={handleHoursSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Employee</label>
              <select 
                value={selectedEmp} 
                onChange={e => setSelectedEmp(e.target.value)}
                className="w-full p-3 rounded bg-gray-50 dark:bg-black border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-ramp-gold focus:outline-none"
              >
                <option value="">Select Employee...</option>
                {state.employees.map(e => (
                  <option key={e.id} value={e.id}>{e.firstName} {e.lastName}</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Actual Hours</label>
                <input 
                  type="number" 
                  step="0.5"
                  value={actual}
                  onChange={e => setActual(e.target.value)}
                  className="w-full p-3 rounded bg-gray-50 dark:bg-black border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-ramp-gold focus:outline-none"
                  placeholder="e.g. 8.0"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Billable Hours</label>
                <input 
                  type="number" 
                  step="0.5"
                  value={billable}
                  onChange={e => setBillable(e.target.value)}
                  className="w-full p-3 rounded bg-gray-50 dark:bg-black border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-ramp-gold focus:outline-none"
                  placeholder="e.g. 6.5"
                  required
                />
              </div>
            </div>

            {hoursError && (
              <div className="p-3 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded flex items-center">
                <AlertCircle className="w-4 h-4 mr-2" />
                {hoursError}
              </div>
            )}
            
            {hoursSuccess && (
              <div className="p-3 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded">
                {hoursSuccess}
              </div>
            )}

            <button type="submit" className="w-full bg-ramp-gold hover:bg-yellow-500 text-black font-bold py-3 px-4 rounded transition-colors flex justify-center items-center">
              <Send className="w-4 h-4 mr-2" />
              Submit Hours
            </button>
          </form>
        </div>
      )}

      {activeTab === 'travel' && (
        <div className="bg-white dark:bg-ramp-surface p-8 rounded-lg shadow-lg border border-gray-100 dark:border-gray-700">
          <h3 className="text-xl font-bold mb-6 text-gray-900 dark:text-ramp-text">Travel Reimbursement Request</h3>
          <form onSubmit={handleTravelSubmit} className="space-y-6">
            <div>
               <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Employee</label>
               <select 
                  value={travelEmp} 
                  onChange={e => setTravelEmp(e.target.value)}
                  className="w-full p-3 rounded bg-gray-50 dark:bg-black border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-ramp-gold focus:outline-none"
                  required
                >
                  <option value="">Select Employee...</option>
                  {state.employees.map(e => (
                    <option key={e.id} value={e.id}>{e.firstName} {e.lastName}</option>
                  ))}
                </select>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Lodging Cost ($)</label>
                <div className="relative">
                  <span className="absolute left-3 top-3 text-gray-500">$</span>
                  <input 
                    type="number" 
                    step="0.01"
                    value={lodging}
                    onChange={e => setLodging(e.target.value)}
                    className="w-full p-3 pl-8 rounded bg-gray-50 dark:bg-black border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-ramp-gold focus:outline-none"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Distance (Miles)</label>
                 <div className="relative">
                  <MapPin className="absolute left-3 top-3 text-gray-500 w-4 h-4" />
                  <input 
                    type="number" 
                    step="0.1"
                    value={miles}
                    onChange={e => setMiles(e.target.value)}
                    className="w-full p-3 pl-10 rounded bg-gray-50 dark:bg-black border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-ramp-gold focus:outline-none"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="bg-gray-50 dark:bg-black p-4 rounded border border-gray-200 dark:border-gray-800 flex justify-between items-center">
               <div className="text-sm text-gray-500">
                  <p>Standard Rate: $0.67 / mile</p>
               </div>
               <div className="text-right">
                  <span className="text-xs text-gray-400 uppercase">Estimated Total</span>
                  <div className="text-xl font-bold text-ramp-gold">
                    ${((parseFloat(miles)||0) * 0.67 + (parseFloat(lodging)||0)).toFixed(2)}
                  </div>
               </div>
            </div>

            {travelSuccess && (
              <div className="p-3 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded">
                {travelSuccess}
              </div>
            )}

            <button type="submit" className="w-full bg-ramp-gold hover:bg-yellow-500 text-black font-bold py-3 px-4 rounded transition-colors flex justify-center items-center">
              <Calculator className="w-4 h-4 mr-2" />
              Submit Request
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
