import React, { useMemo } from 'react';
import { Shift, Employee, TooltipConfig } from '../types';
import { Tooltip } from './Tooltip';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { DollarSign, Clock, TrendingUp, AlertTriangle } from 'lucide-react';

interface DashboardProps {
  shifts: Shift[];
  employees: Employee[];
  tooltips: TooltipConfig;
}

export const Dashboard: React.FC<DashboardProps> = ({ shifts, employees, tooltips }) => {
  
  // --- Calculations ---

  const metrics = useMemo(() => {
    let totalPlannedBudget = 0;
    let totalActualBudget = 0;
    let totalCV = 0;
    let totalSV = 0;
    
    // Duration in days
    const getDuration = (start: string, end: string) => {
      if (!start || !end) return 0;
      const s = new Date(start).getTime();
      const e = new Date(end).getTime();
      return (e - s) / (1000 * 3600 * 24);
    };

    shifts.forEach(shift => {
      totalPlannedBudget += shift.plannedBudget;
      totalActualBudget += shift.actualBudget;

      // Cost Variance: Planned - Actual (Positive is Good)
      const cv = shift.plannedBudget - shift.actualBudget;
      totalCV += cv;

      // Schedule Variance (Duration): Planned Duration - Actual Duration (Positive is Good - finished faster)
      // Logic from prompt: (PlannedEnd - PlannedStart) - (ActualEnd - ActualStart)
      const plannedDur = getDuration(shift.plannedStart, shift.plannedEnd);
      const actualDur = getDuration(shift.actualStart, shift.actualEnd);
      
      // If actual duration is 0 (not started/finished), we assume 0 variance or handle differently.
      // For this PoC, we only calc SV if actualStart is present.
      if (shift.actualStart && shift.actualEnd) {
        totalSV += (plannedDur - actualDur);
      }
    });

    return {
      totalPlannedBudget,
      totalActualBudget,
      totalCV,
      totalSV,
      programVariance: totalCV // Assuming simple sum for now as per prompt "Sum(All Shift CVs) + Sum(All Shift SVs)" - typically units differ ($ vs days), but sticking to prompt request for visual PoC, we might display separately.
    };
  }, [shifts]);

  const chartData = shifts.map(s => ({
    name: `S${s.id}`,
    Planned: s.plannedBudget,
    Actual: s.actualBudget,
  }));

  // --- Components ---

  const MetricCard = ({ title, value, subtext, icon: Icon, isGood, tooltipKey }: any) => (
    <div className="bg-white dark:bg-ramp-surface p-6 rounded-lg shadow-md border-l-4 border-ramp-gold">
      <div className="flex justify-between items-start mb-2">
        <h3 className="text-gray-500 dark:text-gray-400 text-sm font-medium flex items-center">
          {title}
          <Tooltip content={tooltips[tooltipKey] || ''} />
        </h3>
        <div className="p-2 bg-gray-100 dark:bg-black rounded-full">
          <Icon className="w-5 h-5 text-ramp-gold" />
        </div>
      </div>
      <div className={`text-2xl font-bold ${isGood === undefined ? 'text-gray-900 dark:text-ramp-text' : isGood ? 'text-green-500' : 'text-red-500'}`}>
        {value}
      </div>
      {subtext && <p className="text-xs text-gray-400 mt-1">{subtext}</p>}
    </div>
  );

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard 
          title="Total Budget (Planned)" 
          value={`$${metrics.totalPlannedBudget.toLocaleString()}`}
          icon={DollarSign}
          tooltipKey="cv_label" // Using existing keys from constants
        />
        <MetricCard 
          title="Cost Variance (CV)" 
          value={`$${metrics.totalCV.toLocaleString()}`}
          isGood={metrics.totalCV >= 0}
          subtext={metrics.totalCV >= 0 ? "Under Budget" : "Over Budget"}
          icon={TrendingUp}
          tooltipKey="cv_label"
        />
        <MetricCard 
          title="Schedule Variance (SV)" 
          value={`${metrics.totalSV.toFixed(1)} Days`}
          isGood={metrics.totalSV >= 0}
          subtext={metrics.totalSV >= 0 ? "Ahead of Schedule" : "Behind Schedule"}
          icon={Clock}
          tooltipKey="sv_label"
        />
        <MetricCard 
          title="Program Health" 
          value={metrics.totalCV >= 0 && metrics.totalSV >= 0 ? "ON TRACK" : "AT RISK"}
          isGood={metrics.totalCV >= 0 && metrics.totalSV >= 0}
          icon={AlertTriangle}
          tooltipKey="prog_var_label"
        />
      </div>

      {/* Main Charts Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Gantt Roll-up (Custom Visual) */}
        <div className="lg:col-span-2 bg-white dark:bg-ramp-surface p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-bold text-gray-900 dark:text-ramp-text mb-6 border-b border-gray-200 dark:border-gray-700 pb-2">
            Executive Gantt Roll-up
          </h2>
          <div className="space-y-6">
            {shifts.map((shift) => {
              // Very simplified % calculation for PoC visualization relative to a fixed range
              // Assuming range Oct 1 2023 to Feb 1 2024 (approx 120 days)
              const startBase = new Date('2023-10-01').getTime();
              const endBase = new Date('2024-02-01').getTime();
              const totalRange = endBase - startBase;

              const getPos = (dateStr: string) => {
                if (!dateStr) return 0;
                const d = new Date(dateStr).getTime();
                return Math.max(0, ((d - startBase) / totalRange) * 100);
              };

              const pStart = getPos(shift.plannedStart);
              const pWidth = getPos(shift.plannedEnd) - pStart;
              const aStart = getPos(shift.actualStart);
              const aWidth = shift.actualEnd ? getPos(shift.actualEnd) - aStart : (shift.actualStart ? 5 : 0); // show small bar if started but not finished

              return (
                <div key={shift.id} className="relative">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium text-gray-700 dark:text-ramp-text flex items-center">
                      {shift.name} 
                      <Tooltip content={tooltips[`shift_${shift.id}_label`] || shift.description} />
                    </span>
                    <span className="text-xs text-gray-500">{shift.plannedStart} - {shift.plannedEnd}</span>
                  </div>
                  {/* Timeline container */}
                  <div className="h-8 bg-gray-100 dark:bg-black rounded-full relative w-full overflow-hidden">
                    {/* Planned Bar */}
                    <div 
                      className="absolute top-0 h-4 bg-gray-400 opacity-50 rounded-t-full"
                      style={{ left: `${pStart}%`, width: `${pWidth}%` }}
                      title={`Planned: ${shift.plannedStart} to ${shift.plannedEnd}`}
                    />
                    {/* Actual Bar */}
                    <div 
                      className={`absolute bottom-0 h-4 rounded-b-full ${shift.actualBudget > shift.plannedBudget ? 'bg-red-500' : 'bg-ramp-gold'}`}
                      style={{ left: `${aStart}%`, width: `${Math.max(aWidth, 1)}%` }} // Ensure visible
                      title="Actual Progress"
                    />
                  </div>
                </div>
              );
            })}
          </div>
          
          <div className="mt-6 flex gap-4 text-xs justify-end text-gray-500">
             <div className="flex items-center"><div className="w-3 h-3 bg-gray-400 opacity-50 mr-1"></div> Planned</div>
             <div className="flex items-center"><div className="w-3 h-3 bg-ramp-gold mr-1"></div> Actual (On Budget)</div>
             <div className="flex items-center"><div className="w-3 h-3 bg-red-500 mr-1"></div> Actual (Over Budget)</div>
          </div>
        </div>

        {/* Budget vs Actual Chart */}
        <div className="bg-white dark:bg-ramp-surface p-6 rounded-lg shadow-md">
           <h2 className="text-xl font-bold text-gray-900 dark:text-ramp-text mb-6 border-b border-gray-200 dark:border-gray-700 pb-2">
            Budget Variance
          </h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#444" opacity={0.2} />
                <XAxis dataKey="name" stroke="#888" />
                <YAxis stroke="#888" />
                <RechartsTooltip 
                  contentStyle={{ backgroundColor: '#1E1E1E', borderColor: '#D4AF37', color: '#fff' }}
                />
                <Legend />
                <Bar dataKey="Planned" fill="#888888" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Actual" fill="#D4AF37" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Employee Roll-up Table */}
      <div className="bg-white dark:bg-ramp-surface rounded-lg shadow-md overflow-hidden">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-bold text-gray-900 dark:text-ramp-text">Employee Utilization</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-gray-50 dark:bg-black text-gray-500 dark:text-gray-400 uppercase text-xs">
              <tr>
                <th className="p-4">Name</th>
                <th className="p-4">Cohort</th>
                <th className="p-4 text-right">Wage/Hr</th>
                <th className="p-4 text-right">Billable Hrs</th>
                <th className="p-4 text-right">Actual Hrs</th>
                <th className="p-4 text-right">Utilization %</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-800">
              {employees.map(emp => {
                 const util = (emp.billableHours / emp.actualHours) * 100;
                 return (
                  <tr key={emp.id} className="hover:bg-gray-50 dark:hover:bg-white/5">
                    <td className="p-4 text-gray-900 dark:text-ramp-text font-medium">{emp.firstName} {emp.lastName}</td>
                    <td className="p-4 text-gray-600 dark:text-gray-400">{emp.cohortId}</td>
                    <td className="p-4 text-right text-gray-600 dark:text-gray-400">${emp.wage}</td>
                    <td className="p-4 text-right text-gray-600 dark:text-gray-400">{emp.billableHours}</td>
                    <td className="p-4 text-right text-gray-600 dark:text-gray-400">{emp.actualHours}</td>
                    <td className="p-4 text-right">
                      <span className={`px-2 py-1 rounded text-xs font-bold ${util >= 90 ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                        {util.toFixed(1)}%
                      </span>
                    </td>
                  </tr>
                 );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
