import React, { useState } from 'react';
import { AppState, Shift, TooltipConfig, ExternalRep } from '../types';
import { Save, Plus, Trash2, Edit } from 'lucide-react';

interface AdminProps {
  state: AppState;
  updateShift: (shift: Shift) => void;
  updateTooltip: (key: string, val: string) => void;
  addExternalRep: (rep: ExternalRep) => void;
}

export const Admin: React.FC<AdminProps> = ({ state, updateShift, updateTooltip, addExternalRep }) => {
  const [activeSection, setActiveSection] = useState<'shifts' | 'tooltips' | 'reps'>('shifts');

  // Rep Form State
  const [repName, setRepName] = useState('');
  const [repCompany, setRepCompany] = useState('');

  const handleRepSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (repName && repCompany) {
      addExternalRep({
        id: Date.now().toString(),
        name: repName,
        company: repCompany
      });
      setRepName('');
      setRepCompany('');
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex space-x-2 mb-6">
        {['shifts', 'tooltips', 'reps'].map((sec) => (
          <button
            key={sec}
            onClick={() => setActiveSection(sec as any)}
            className={`px-4 py-2 rounded-md text-sm font-semibold capitalize transition-colors ${
              activeSection === sec 
              ? 'bg-ramp-gold text-black' 
              : 'bg-white dark:bg-ramp-surface text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-black'
            }`}
          >
            {sec === 'reps' ? 'External Reps' : sec}
          </button>
        ))}
      </div>

      {activeSection === 'shifts' && (
        <div className="bg-white dark:bg-ramp-surface rounded-lg shadow overflow-hidden">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="font-bold text-gray-900 dark:text-ramp-text">Milestone Management (Shifts 1-5)</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-50 dark:bg-black text-xs uppercase text-gray-500">
                <tr>
                  <th className="p-3">Shift</th>
                  <th className="p-3">Plan Start</th>
                  <th className="p-3">Plan End</th>
                  <th className="p-3">Budget ($)</th>
                  <th className="p-3">Actual Budget ($)</th>
                  <th className="p-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-800">
                {state.shifts.map((shift) => (
                  <tr key={shift.id}>
                    <td className="p-3 font-medium text-gray-900 dark:text-ramp-text">{shift.name}</td>
                    <td className="p-3">
                      <input 
                        type="date" 
                        value={shift.plannedStart} 
                        onChange={(e) => updateShift({ ...shift, plannedStart: e.target.value })}
                        className="bg-transparent border border-transparent hover:border-gray-300 dark:hover:border-gray-600 rounded px-1 text-gray-700 dark:text-gray-300 focus:ring-1 focus:ring-ramp-gold focus:outline-none"
                      />
                    </td>
                    <td className="p-3">
                       <input 
                        type="date" 
                        value={shift.plannedEnd} 
                        onChange={(e) => updateShift({ ...shift, plannedEnd: e.target.value })}
                        className="bg-transparent border border-transparent hover:border-gray-300 dark:hover:border-gray-600 rounded px-1 text-gray-700 dark:text-gray-300 focus:ring-1 focus:ring-ramp-gold focus:outline-none"
                      />
                    </td>
                    <td className="p-3">
                      <input 
                        type="number" 
                        value={shift.plannedBudget} 
                        onChange={(e) => updateShift({ ...shift, plannedBudget: parseInt(e.target.value) })}
                        className="w-24 bg-transparent border border-transparent hover:border-gray-300 dark:hover:border-gray-600 rounded px-1 text-gray-700 dark:text-gray-300 focus:ring-1 focus:ring-ramp-gold focus:outline-none"
                      />
                    </td>
                     <td className="p-3">
                      <input 
                        type="number" 
                        value={shift.actualBudget} 
                        onChange={(e) => updateShift({ ...shift, actualBudget: parseInt(e.target.value) })}
                        className="w-24 bg-transparent border border-transparent hover:border-gray-300 dark:hover:border-gray-600 rounded px-1 text-gray-700 dark:text-gray-300 focus:ring-1 focus:ring-ramp-gold focus:outline-none"
                      />
                    </td>
                    <td className="p-3">
                      <button className="text-ramp-gold hover:text-white transition-colors" title="Auto-saved on change">
                        <Save className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeSection === 'tooltips' && (
        <div className="bg-white dark:bg-ramp-surface rounded-lg shadow p-6">
           <h3 className="font-bold text-gray-900 dark:text-ramp-text mb-4">Hover-Text Manager (CMS)</h3>
           <div className="grid grid-cols-1 gap-4">
             {Object.keys(state.tooltips).map((key) => (
               <div key={key} className="flex flex-col md:flex-row md:items-center gap-2 pb-4 border-b border-gray-100 dark:border-gray-800 last:border-0">
                 <div className="md:w-1/4 font-mono text-xs text-gray-500">{key}</div>
                 <input 
                    type="text" 
                    value={state.tooltips[key]} 
                    onChange={(e) => updateTooltip(key, e.target.value)}
                    className="flex-1 p-2 bg-gray-50 dark:bg-black border border-gray-200 dark:border-gray-700 rounded text-gray-900 dark:text-white focus:ring-1 focus:ring-ramp-gold focus:outline-none"
                 />
               </div>
             ))}
           </div>
        </div>
      )}

      {activeSection === 'reps' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-ramp-surface rounded-lg shadow p-6">
            <h3 className="font-bold text-gray-900 dark:text-ramp-text mb-4">Add External Representative</h3>
            <form onSubmit={handleRepSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">Full Name</label>
                <input 
                  type="text"
                  value={repName}
                  onChange={e => setRepName(e.target.value)}
                  className="w-full p-2 rounded bg-gray-50 dark:bg-black border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">Company / Vendor</label>
                <input 
                  type="text"
                  value={repCompany}
                  onChange={e => setRepCompany(e.target.value)}
                  className="w-full p-2 rounded bg-gray-50 dark:bg-black border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white"
                  required
                />
              </div>
              <button type="submit" className="w-full bg-ramp-gold text-black font-bold py-2 rounded hover:bg-yellow-500 transition-colors flex justify-center items-center">
                <Plus className="w-4 h-4 mr-2" />
                Add Representative
              </button>
            </form>
          </div>

          <div className="bg-white dark:bg-ramp-surface rounded-lg shadow overflow-hidden">
             <div className="p-4 border-b border-gray-200 dark:border-gray-700">
               <h3 className="font-bold text-gray-900 dark:text-ramp-text">Current Vendor List</h3>
             </div>
             <ul className="divide-y divide-gray-200 dark:divide-gray-800">
               {state.externalReps.length === 0 && <li className="p-4 text-gray-500 text-sm">No external reps added.</li>}
               {state.externalReps.map(rep => (
                 <li key={rep.id} className="p-4 flex justify-between items-center">
                   <div>
                     <p className="font-medium text-gray-900 dark:text-ramp-text">{rep.name}</p>
                     <p className="text-xs text-gray-500">{rep.company}</p>
                   </div>
                   <button className="text-gray-400 hover:text-red-500">
                     <Trash2 className="w-4 h-4" />
                   </button>
                 </li>
               ))}
             </ul>
          </div>
        </div>
      )}
    </div>
  );
};
